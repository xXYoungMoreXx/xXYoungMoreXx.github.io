const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

async function criarUsuario() {
  const pool = new Pool({
    connectionString: 'postgresql://postgres:SUA_SENHA@localhost:5432/clinica_db'
  });

  try {
    // Criptografar senha
    const senhaHash = await bcrypt.hash('admin123', 10);
    console.log('Hash gerado:', senhaHash);

    // Inserir usuário
    const result = await pool.query(
      'INSERT INTO usuarios (nome, email, senha, tipo) VALUES ($1, $2, $3, $4) RETURNING *',
      ['Admin Teste', 'admin@teste.com', senhaHash, 'secretario']
    );

    console.log('✅ Usuário criado:', result.rows[0]);
  } catch (error) {
    console.error('❌ Erro:', error.message);
  }

  await pool.end();
}

criarUsuario();