const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Configuração do PostgreSQL
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://user:password@localhost/clinica_db',
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'seu_jwt_secret_aqui';

// Middleware de autenticação
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acesso requerido' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

// Inicialização do banco de dados
const initDatabase = async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id SERIAL PRIMARY KEY,
        nome VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        senha VARCHAR(255) NOT NULL,
        tipo VARCHAR(20) NOT NULL DEFAULT 'paciente',
        telefone VARCHAR(20),
        cep VARCHAR(10),
        endereco TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS agendamentos (
        id SERIAL PRIMARY KEY,
        paciente_id INTEGER REFERENCES usuarios(id),
        data_consulta DATE NOT NULL,
        hora_consulta TIME NOT NULL,
        especialidade VARCHAR(100),
        medico VARCHAR(255),
        observacoes TEXT,
        status VARCHAR(20) DEFAULT 'agendado',
        previsao_clima TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    console.log('Banco de dados inicializado com sucesso!');
  } catch (error) {
    console.error('Erro ao inicializar banco:', error);
  }
};

// Rotas de Autenticação

// Cadastro de usuário
app.post('/api/register', async (req, res) => {
  try {
    const { nome, email, senha, tipo, telefone, cep } = req.body;

    // Validação básica
    if (!nome || !email || !senha) {
      return res.status(400).json({ error: 'Nome, email e senha são obrigatórios' });
    }

    // Verificar se usuário já existe
    const userExists = await pool.query('SELECT id FROM usuarios WHERE email = $1', [email]);
    if (userExists.rows.length > 0) {
      return res.status(400).json({ error: 'Usuário já existe' });
    }

    // Buscar endereço pelo CEP se fornecido
    let endereco = '';
    if (cep) {
      try {
        const cepResponse = await axios.get(`https://viacep.com.br/ws/${cep}/json/`);
        if (cepResponse.data && !cepResponse.data.erro) {
          endereco = `${cepResponse.data.logradouro}, ${cepResponse.data.bairro}, ${cepResponse.data.localidade} - ${cepResponse.data.uf}`;
        }
      } catch (error) {
        console.log('Erro ao buscar CEP:', error.message);
      }
    }

    // Criptografar senha
    const hashedPassword = await bcrypt.hash(senha, 10);

    // Inserir usuário
    const result = await pool.query(
      'INSERT INTO usuarios (nome, email, senha, tipo, telefone, cep, endereco) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id',
      [nome, email, hashedPassword, tipo || 'paciente', telefone, cep, endereco]
    );

    res.status(201).json({
      message: 'Usuário cadastrado com sucesso',
      userId: result.rows[0].id
    });
  } catch (error) {
    console.error('Erro no cadastro:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  try {
    const { email, senha } = req.body;

    console.log('=== DEBUG LOGIN ===');
    console.log('Email recebido:', email);
    console.log('Senha recebida:', senha);
    console.log('Tipo email:', typeof email);
    console.log('Tipo senha:', typeof senha);

    if (!email || !senha) {
      console.log('❌ Email ou senha vazios');
      return res.status(400).json({ error: 'Email e senha são obrigatórios' });
    }

    // Buscar usuário
    console.log('🔍 Buscando usuário no banco...');
    const user = await pool.query('SELECT * FROM usuarios WHERE email = $1', [email]);
    console.log('Usuários encontrados:', user.rows.length);
    
    if (user.rows.length === 0) {
      console.log('❌ Usuário não encontrado no banco para email:', email);
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const userData = user.rows[0];
    console.log('✅ Usuário encontrado:');
    console.log('- ID:', userData.id);
    console.log('- Nome:', userData.nome);
    console.log('- Email:', userData.email);
    console.log('- Tipo:', userData.tipo);
    console.log('- Hash senha (primeiros 20 chars):', userData.senha.substring(0, 20) + '...');

    // Verificar senha
    console.log('🔐 Verificando senha...');
    console.log('Senha digitada:', senha);
    console.log('Hash no banco:', userData.senha);
    
    const validPassword = await bcrypt.compare(senha, userData.senha);
    console.log('Resultado bcrypt.compare:', validPassword);
    
    if (!validPassword) {
      console.log('❌ Senha inválida');
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    console.log('✅ Login bem-sucedido!');

    // Gerar token
    const token = jwt.sign(
      { 
        id: userData.id, 
        email: userData.email, 
        tipo: userData.tipo,
        nome: userData.nome
      },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    console.log('✅ Token gerado');

    res.json({
      token,
      user: {
        id: userData.id,
        nome: userData.nome,
        email: userData.email,
        tipo: userData.tipo
      }
    });
    
  } catch (error) {
    console.error('💥 Erro no login:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Rotas de Agendamento

// Criar agendamento
app.post('/api/agendamentos', authenticateToken, async (req, res) => {
  try {
    const { data_consulta, hora_consulta, especialidade, medico, observacoes } = req.body;
    const paciente_id = req.user.id;

    // Verificar se horário está disponível
    const conflito = await pool.query(
      'SELECT id FROM agendamentos WHERE data_consulta = $1 AND hora_consulta = $2 AND status != $3',
      [data_consulta, hora_consulta, 'cancelado']
    );

    if (conflito.rows.length > 0) {
      return res.status(400).json({ error: 'Horário não disponível' });
    }

    // Buscar previsão do tempo para a data da consulta
    let previsao_clima = '';
    try {
      const weatherResponse = await axios.get(
        `https://api.openweathermap.org/data/2.5/forecast?q=Salvador,BR&appid=${process.env.OPENWEATHER_API_KEY}&units=metric&lang=pt_br`
      );
      
      if (weatherResponse.data && weatherResponse.data.list) {
        const consultaDate = new Date(data_consulta);
        const forecast = weatherResponse.data.list.find(item => {
          const forecastDate = new Date(item.dt * 1000);
          return forecastDate.toDateString() === consultaDate.toDateString();
        });

        if (forecast) {
          const chuva = forecast.weather.some(w => w.main.toLowerCase().includes('rain'));
          previsao_clima = chuva 
            ? `⚠️ Previsão de chuva: ${forecast.weather[0].description}. Temperatura: ${Math.round(forecast.main.temp)}°C`
            : `☀️ Tempo bom: ${forecast.weather[0].description}. Temperatura: ${Math.round(forecast.main.temp)}°C`;
        }
      }
    } catch (error) {
      console.log('Erro ao buscar clima:', error.message);
      previsao_clima = 'Não foi possível obter previsão do tempo';
    }

    // Inserir agendamento
    const result = await pool.query(
      'INSERT INTO agendamentos (paciente_id, data_consulta, hora_consulta, especialidade, medico, observacoes, previsao_clima) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
      [paciente_id, data_consulta, hora_consulta, especialidade, medico, observacoes, previsao_clima]
    );

    res.status(201).json({
      message: 'Agendamento criado com sucesso',
      agendamento: result.rows[0]
    });
  } catch (error) {
    console.error('Erro ao criar agendamento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Listar agendamentos do usuário
app.get('/api/agendamentos', authenticateToken, async (req, res) => {
  try {
    let query, params;
    
    if (req.user.tipo === 'secretario') {
      // Secretários veem todos os agendamentos
      query = `
        SELECT 
          a.id,
          a.data_consulta,
          TO_CHAR(a.data_consulta, 'YYYY-MM-DD') as data_formatada,
          a.hora_consulta,
          a.especialidade,
          a.medico,
          a.observacoes,
          a.status,
          a.previsao_clima,
          a.created_at,
          u.nome as paciente_nome, 
          u.telefone as paciente_telefone 
        FROM agendamentos a 
        JOIN usuarios u ON a.paciente_id = u.id 
        ORDER BY a.data_consulta DESC, a.hora_consulta DESC
      `;
      params = [];
    } else {
      // Pacientes veem apenas seus agendamentos
      query = `
        SELECT 
          a.id,
          a.data_consulta,
          TO_CHAR(a.data_consulta, 'YYYY-MM-DD') as data_formatada,
          a.hora_consulta,
          a.especialidade,
          a.medico,
          a.observacoes,
          a.status,
          a.previsao_clima,
          a.created_at,
          u.nome as paciente_nome, 
          u.telefone as paciente_telefone 
        FROM agendamentos a 
        JOIN usuarios u ON a.paciente_id = u.id 
        WHERE a.paciente_id = $1 
        ORDER BY a.data_consulta DESC, a.hora_consulta DESC
      `;
      params = [req.user.id];
    }

    const result = await pool.query(query, params);
    
    // Processar datas antes de enviar
    const agendamentos = result.rows.map(row => ({
      ...row,
      data_consulta: row.data_formatada || row.data_consulta
    }));
    
    res.json(agendamentos);
  } catch (error) {
    console.error('Erro ao buscar agendamentos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});
// Listar agendamentos do usuário
app.get('/api/agendamentos', authenticateToken, async (req, res) => {
  try {
    let query, params;
    
    if (req.user.tipo === 'secretario') {
      // Secretários veem todos os agendamentos
      query = `
        SELECT a.*, u.nome as paciente_nome, u.telefone as paciente_telefone 
        FROM agendamentos a 
        JOIN usuarios u ON a.paciente_id = u.id 
        ORDER BY a.data_consulta DESC, a.hora_consulta DESC
      `;
      params = [];
    } else {
      // Pacientes veem apenas seus agendamentos
      query = `
        SELECT a.*, u.nome as paciente_nome, u.telefone as paciente_telefone 
        FROM agendamentos a 
        JOIN usuarios u ON a.paciente_id = u.id 
        WHERE a.paciente_id = $1 
        ORDER BY a.data_consulta DESC, a.hora_consulta DESC
      `;
      params = [req.user.id];
    }

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao buscar agendamentos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Atualizar status do agendamento (apenas secretários)
app.put('/api/agendamentos/:id/status', authenticateToken, async (req, res) => {
  try {
    if (req.user.tipo !== 'secretario') {
      return res.status(403).json({ error: 'Acesso negado' });
    }

    const { id } = req.params;
    const { status } = req.body;

    const result = await pool.query(
      'UPDATE agendamentos SET status = $1 WHERE id = $2 RETURNING *',
      [status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Agendamento não encontrado' });
    }

    res.json({
      message: 'Status atualizado com sucesso',
      agendamento: result.rows[0]
    });
  } catch (error) {
    console.error('Erro ao atualizar status:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Rota para buscar endereço por CEP
app.get('/api/cep/:cep', async (req, res) => {
  try {
    const { cep } = req.params;
    const response = await axios.get(`https://viacep.com.br/ws/${cep}/json/`);
    
    if (response.data.erro) {
      return res.status(404).json({ error: 'CEP não encontrado' });
    }
    
    res.json(response.data);
  } catch (error) {
    console.error('Erro ao buscar CEP:', error);
    res.status(500).json({ error: 'Erro ao buscar CEP' });
  }
});

// Verificar horários disponíveis
app.get('/api/horarios-disponiveis', authenticateToken, async (req, res) => {
  try {
    const { data } = req.query;
    
    if (!data) {
      return res.status(400).json({ error: 'Data é obrigatória' });
    }

    const agendados = await pool.query(
      'SELECT hora_consulta FROM agendamentos WHERE data_consulta = $1 AND status != $2',
      [data, 'cancelado']
    );

    const horariosOcupados = agendados.rows.map(row => row.hora_consulta);
    const todosHorarios = [
      '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
      '11:00', '11:30', '14:00', '14:30', '15:00', '15:30',
      '16:00', '16:30', '17:00', '17:30'
    ];

    const horariosDisponiveis = todosHorarios.filter(
      horario => !horariosOcupados.includes(horario)
    );

    res.json(horariosDisponiveis);
  } catch (error) {
    console.error('Erro ao buscar horários:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Inicializar servidor
const startServer = async () => {
  await initDatabase();
  app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
  });
};

startServer();