const { Pool } = require('pg');

const pool = new Pool({
  connectionString: 'postgresql://postgres:@Young123@localhost:5432/clinica_db'
});

async function testarConexao() {
  try {
    const result = await pool.query('SELECT NOW()');
    console.log('✅ Conexão OK:', result.rows[0]);
    
    const usuarios = await pool.query('SELECT * FROM usuarios');
    console.log('✅ Usuários encontrados:', usuarios.rows);
    
  } catch (error) {
    console.error('❌ Erro de conexão:', error.message);
  }
  
  await pool.end();
}

testarConexao();