const bcrypt = require('bcryptjs');
const { Pool } = require('pg');
require('dotenv').config();

async function corrigirSenhas() {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL
  });

  try {
    console.log('🔧 Corrigindo senhas dos usuários...');
    
    // Verificar conexão
    const testConn = await pool.query('SELECT NOW()');
    console.log('✅ Conexão OK');

    // Ver usuários atuais
    const usuarios = await pool.query('SELECT id, nome, email, tipo FROM usuarios');
    console.log('📋 Usuários encontrados:', usuarios.rows);

    // Gerar hashes corretos
    const hashAdmin = await bcrypt.hash('admin123', 10);
    const hashTeste = await bcrypt.hash('teste123', 10);
    
    console.log('🔐 Hash para admin123:', hashAdmin.substring(0, 20) + '...');
    console.log('🔐 Hash para teste123:', hashTeste.substring(0, 20) + '...');

    // Testar hashes
    const testeAdmin = await bcrypt.compare('admin123', hashAdmin);
    const testeTeste = await bcrypt.compare('teste123', hashTeste);
    console.log('✅ Teste hash admin:', testeAdmin ? 'OK' : 'ERRO');
    console.log('✅ Teste hash teste:', testeTeste ? 'OK' : 'ERRO');

    // Atualizar senhas
    console.log('📝 Atualizando senhas...');
    
    // Atualizar admin
    const adminUpdate = await pool.query(
      'UPDATE usuarios SET senha = $1 WHERE email = $2 RETURNING email',
      [hashAdmin, 'admin@clinica.com']
    );
    
    // Atualizar paciente (joao)
    const pacienteUpdate = await pool.query(
      'UPDATE usuarios SET senha = $1 WHERE email = $2 RETURNING email',
      [hashTeste, 'joao@email.com']
    );

    console.log('✅ Senhas atualizadas:');
    console.log('- Admin:', adminUpdate.rows[0]?.email || 'NÃO ENCONTRADO');
    console.log('- Paciente:', pacienteUpdate.rows[0]?.email || 'NÃO ENCONTRADO');

    // Verificar resultado
    const verificacao = await pool.query('SELECT email, LENGTH(senha) as len FROM usuarios');
    console.log('📊 Verificação final:', verificacao.rows);

    console.log('\n🎯 Use estas credenciais:');
    console.log('Secretário: admin@clinica.com / admin123');
    console.log('Paciente: joao@email.com / teste123');

  } catch (error) {
    console.error('💥 Erro:', error.message);
  }

  await pool.end();
}

corrigirSenhas();