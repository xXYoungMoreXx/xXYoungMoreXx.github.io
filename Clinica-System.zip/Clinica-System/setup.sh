#!/bin/bash

# 🏥 Script de Setup - Sistema de Agendamento Clínica Médica
# Este script automatiza a instalação e configuração do sistema

set -e  # Parar execução se algum comando falhar

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções utilitárias
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Banner
echo -e "${BLUE}"
cat << "EOF"
 ██████╗██╗     ██╗███╗   ██╗██╗ ██████╗ █████╗ 
██╔════╝██║     ██║████╗  ██║██║██╔════╝██╔══██╗
██║     ██║     ██║██╔██╗ ██║██║██║     ███████║
██║     ██║     ██║██║╚██╗██║██║██║     ██╔══██║
╚██████╗███████╗██║██║ ╚████║██║╚██████╗██║  ██║
 ╚═════╝╚══════╝╚═╝╚═╝  ╚═══╝╚═╝ ╚═════╝╚═╝  ╚═╝
Sistema de Agendamento - Setup Automático
EOF
echo -e "${NC}"

print_status "Iniciando configuração do sistema..."

# Verificar se o Node.js está instalado
if ! command -v node &> /dev/null; then
    print_error "Node.js não encontrado!"
    echo "Por favor, instale o Node.js 16+ antes de continuar."
    echo "Visite: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 16 ]; then
    print_error "Node.js versão 16+ é necessário. Versão atual: $(node -v)"
    exit 1
fi

print_success "Node.js $(node -v) encontrado"

# Verificar PostgreSQL
if ! command -v psql &> /dev/null; then
    print_warning "PostgreSQL não encontrado!"
    echo "Instalando PostgreSQL..."
    
    # Detectar sistema operacional
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        if command -v apt &> /dev/null; then
            sudo apt update
            sudo apt install -y postgresql postgresql-contrib
        elif command -v yum &> /dev/null; then
            sudo yum install -y postgresql-server postgresql-contrib
            sudo postgresql-setup initdb
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        if command -v brew &> /dev/null; then
            brew install postgresql
            brew services start postgresql
        else
            print_error "Homebrew não encontrado. Instale PostgreSQL manualmente."
            exit 1
        fi
    else
        print_error "Sistema operacional não suportado para instalação automática do PostgreSQL"
        echo "Por favor, instale PostgreSQL manualmente e execute o script novamente."
        exit 1
    fi
fi

print_success "PostgreSQL encontrado"

# Criar estrutura de diretórios
print_status "Criando estrutura de diretórios..."
mkdir -p {backend,frontend,database}

# Configuração do Backend
print_status "Configurando backend..."
cd backend

# Criar package.json se não existir
if [ ! -f "package.json" ]; then
    cat > package.json << 'EOF'
{
  "name": "clinica-backend",
  "version": "1.0.0",
  "description": "Backend para sistema de agendamento de consultas médicas",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "pg": "^8.11.3",
    "axios": "^1.6.0",
    "dotenv": "^16.3.1"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  },
  "keywords": ["nodejs", "express", "postgresql", "jwt", "api"],
  "author": "Sistema de Clínica",
  "license": "MIT"
}
EOF
fi

# Instalar dependências do backend
print_status "Instalando dependências do backend..."
npm install

# Configurar ambiente
if [ ! -f ".env" ]; then
    print_status "Criando arquivo de configuração..."
    cat > .env << EOF
# Configuração do Banco de Dados PostgreSQL
DATABASE_URL=postgresql://clinica_user:clinica123@localhost:5432/clinica_db

# JWT Secret (altere em produção)
JWT_SECRET=sua_chave_secreta_jwt_muito_segura_aqui_$(openssl rand -hex 32)

# API Key do OpenWeatherMap (obtenha em https://openweathermap.org/api)
OPENWEATHER_API_KEY=sua_api_key_openweather_aqui

# Porta do servidor
PORT=3000

# Ambiente
NODE_ENV=development
EOF
    print_warning "Arquivo .env criado! Lembre-se de configurar OPENWEATHER_API_KEY"
fi

cd ..

# Configuração do Banco de Dados
print_status "Configurando banco de dados..."

# Verificar se PostgreSQL está rodando
if ! pgrep -x "postgres" > /dev/null; then
    print_status "Iniciando PostgreSQL..."
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        sudo systemctl start postgresql
        sudo systemctl enable postgresql
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        brew services start postgresql
    fi
fi

# Criar usuário e banco de dados
print_status "Criando banco de dados e usuário..."
sudo -u postgres psql -c "CREATE USER clinica_user WITH PASSWORD 'clinica123';" 2>/dev/null || true
sudo -u postgres psql -c "CREATE DATABASE clinica_db OWNER clinica_user;" 2>/dev/null || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE clinica_db TO clinica_user;" 2>/dev/null || true

# Executar script de inicialização
if [ -f "database/init.sql" ]; then
    print_status "Inicializando banco de dados..."
    PGPASSWORD=clinica123 psql -h localhost -U clinica_user -d clinica_db -f database/init.sql
    print_success "Banco de dados inicializado com sucesso!"
else
    print_warning "Script init.sql não encontrado. Execute manualmente quando disponível."
fi

# Configuração do Frontend
print_status "Configurando frontend..."
cd frontend

if [ ! -f "package.json" ]; then
    cat > package.json << 'EOF'
{
  "name": "clinica-frontend",
  "version": "1.0.0",
  "description": "Frontend para sistema de agendamento de consultas médicas",
  "main": "index.html",
  "scripts": {
    "dev": "live-server --port=8080 --host=localhost --entry-file=index.html",
    "start": "live-server --port=8080 --host=0.0.0.0 --entry-file=index.html"
  },
  "devDependencies": {
    "live-server": "^1.2.2"
  },
  "keywords": ["vue", "frontend", "spa", "agendamento", "clinica"],
  "author": "Sistema de Clínica",
  "license": "MIT"
}
EOF
fi

# Instalar live-server globalmente (opcional)
if ! command -v live-server &> /dev/null; then
    print_status "Instalando live-server..."
    npm install -g live-server 2>/dev/null || {
        print_warning "Falha ao instalar live-server globalmente. Instale manualmente se necessário."
    }
fi

cd ..

# Obter API Key do OpenWeatherMap
print_warning "IMPORTANTE: Configure sua API Key do OpenWeatherMap"
echo "1. Visite: https://openweathermap.org/api"
echo "2. Crie uma conta gratuita"
echo "3. Gere sua API key"
echo "4. Edite o arquivo backend/.env e substitua 'sua_api_key_openweather_aqui' pela sua chave"

# Criar scripts de conveniência
print_status "Criando scripts de conveniência..."

cat > start-backend.sh << 'EOF'
#!/bin/bash
echo "🚀 Iniciando backend..."
cd backend
npm run dev
EOF

cat > start-frontend.sh << 'EOF'
#!/bin/bash
echo "🎨 Iniciando frontend..."
cd frontend
if command -v live-server &> /dev/null; then
    live-server --port=8080
else
    echo "Live-server não encontrado. Abrindo index.html no navegador..."
    if [[ "$OSTYPE" == "darwin"* ]]; then
        open index.html
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        xdg-open index.html
    fi
fi
EOF

cat > start-all.sh << 'EOF'
#!/bin/bash
echo "🏥 Iniciando Sistema de Clínica Médica..."

# Verificar se PostgreSQL está rodando
if ! pgrep -x "postgres" > /dev/null; then
    echo "📊 Iniciando PostgreSQL..."
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        sudo systemctl start postgresql
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        brew services start postgresql
    fi
    sleep 2
fi

# Iniciar backend em background
echo "🚀 Iniciando backend..."
cd backend
npm run dev &
BACKEND_PID=$!

# Aguardar backend inicializar
sleep 5

# Iniciar frontend
echo "🎨 Iniciando frontend..."
cd ../frontend
if command -v live-server &> /dev/null; then
    live-server --port=8080
else
    echo "Abra index.html no seu navegador"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        open index.html
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        xdg-open index.html
    fi
    wait $BACKEND_PID
fi
EOF

# Tornar scripts executáveis
chmod +x start-backend.sh start-frontend.sh start-all.sh

print_success "Scripts de conveniência criados!"

# Resumo final
echo ""
echo -e "${GREEN}🎉 SETUP CONCLUÍDO COM SUCESSO! 🎉${NC}"
echo ""
echo "📋 PRÓXIMOS PASSOS:"
echo "1. Configure sua API key do OpenWeatherMap em backend/.env"
echo "2. Execute './start-all.sh' para iniciar o sistema completo"
echo "   OU execute separadamente:"
echo "   - Backend: './start-backend.sh'"
echo "   - Frontend: './start-frontend.sh'"
echo ""
echo "🌐 URLs de acesso:"
echo "   - Backend: http://localhost:3000"
echo "   - Frontend: http://localhost:8080"
echo ""
echo "👤 Usuários de teste:"
echo "   - Secretário: admin@clinica.com / admin123"
echo "   - Paciente: joao@email.com / teste123"
echo ""
echo "📚 Documentação completa em README.md"
echo ""

# Verificar se deseja iniciar automaticamente
read -p "Deseja iniciar o sistema agora? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    print_status "Iniciando sistema..."
    ./start-all.sh
fi

print_success "Setup finalizado! 🚀"