-- Script de inicialização do banco de dados
-- Execute este arquivo no PostgreSQL para criar as tabelas

-- Criar banco de dados (execute primeiro)
-- CREATE DATABASE clinica_db;

-- Conectar ao banco clinica_db antes de executar o restante

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    tipo VARCHAR(20) NOT NULL DEFAULT 'paciente',
    telefone VARCHAR(20),
    cep VARCHAR(10),
    endereco TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de agendamentos
CREATE TABLE IF NOT EXISTS agendamentos (
    id SERIAL PRIMARY KEY,
    paciente_id INTEGER REFERENCES usuarios(id) ON DELETE CASCADE,
    data_consulta DATE NOT NULL,
    hora_consulta TIME NOT NULL,
    especialidade VARCHAR(100) NOT NULL,
    medico VARCHAR(255) NOT NULL,
    observacoes TEXT,
    status VARCHAR(20) DEFAULT 'agendado',
    previsao_clima TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraint para evitar agendamentos duplicados no mesmo horário
    UNIQUE(data_consulta, hora_consulta)
);

-- Inserir usuário secretário padrão (senha: admin123)
INSERT INTO usuarios (nome, email, senha, tipo) 
VALUES (
    'Administrador', 
    'admin@clinica.com', 
    '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- senha: admin123
    'secretario'
) ON CONFLICT (email) DO NOTHING;

-- Inserir usuário paciente de teste (senha: teste123)
INSERT INTO usuarios (nome, email, senha, tipo, telefone, cep) 
VALUES (
    'João Silva', 
    'joao@email.com', 
    '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- senha: teste123
    'paciente',
    '(11) 99999-9999',
    '01310-100'
) ON CONFLICT (email) DO NOTHING;

-- Inserir alguns agendamentos de exemplo
INSERT INTO agendamentos (paciente_id, data_consulta, hora_consulta, especialidade, medico, observacoes, status)
VALUES 
    ((SELECT id FROM usuarios WHERE email = 'joao@email.com'), CURRENT_DATE + INTERVAL '1 day', '09:00', 'Clínico Geral', 'Dr. Maria Santos', 'Consulta de rotina', 'agendado'),
    ((SELECT id FROM usuarios WHERE email = 'joao@email.com'), CURRENT_DATE + INTERVAL '7 days', '14:30', 'Cardiologia', 'Dr. Pedro Lima', 'Acompanhamento cardíaco', 'confirmado')
ON CONFLICT (data_consulta, hora_consulta) DO NOTHING;

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_usuarios_tipo ON usuarios(tipo);
CREATE INDEX IF NOT EXISTS idx_agendamentos_paciente ON agendamentos(paciente_id);
CREATE INDEX IF NOT EXISTS idx_agendamentos_data ON agendamentos(data_consulta);
CREATE INDEX IF NOT EXISTS idx_agendamentos_status ON agendamentos(status);

-- Comentários informativos
COMMENT ON TABLE usuarios IS 'Tabela de usuários do sistema (pacientes e secretários)';
COMMENT ON TABLE agendamentos IS 'Tabela de agendamentos de consultas médicas';
COMMENT ON COLUMN usuarios.tipo IS 'Tipo de usuário: paciente ou secretario';
COMMENT ON COLUMN agendamentos.status IS 'Status: agendado, confirmado, cancelado';

COMMIT;